//
//  ViewFoeHeader.swift
//  SAMPLE TASK
//
//  Created by Toqsoft on 24/05/24.
//

import Foundation
import UIKit

class ViewFoeHeader : UIView {
    
}
