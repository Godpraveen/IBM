//
//  UnitModel.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import Foundation
// MARK: - UnitListElement
struct UnitListElement: Codable {
    let id, partitionKey: String
    let rowid: Int
    let createddate, createdby, name, description: String
    let disabled: Bool
}
