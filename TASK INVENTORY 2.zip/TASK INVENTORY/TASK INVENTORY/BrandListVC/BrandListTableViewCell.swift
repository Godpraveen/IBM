//
//  BrandListTableViewCell.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 09/07/24.
//

import UIKit

class BrandListTableViewCell: UITableViewCell {

    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var crearedBy: UILabel!
    @IBOutlet weak var imageLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var rowIdLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
