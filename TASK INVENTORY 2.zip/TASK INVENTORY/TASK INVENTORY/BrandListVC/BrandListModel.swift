//
//  BrandListModel.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 09/07/24.
//

import Foundation

// MARK: - ProductListElement
struct ProductListElement: Codable {
    let id, partitionKey: String
    let rowid: Int
    let createddate: String
    let createdby: String
    let name, description: String
    let image: String
    let disabled: Bool
}

