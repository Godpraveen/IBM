//
//  BrandViewHeader.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 09/07/24.
//

import Foundation
import UIKit
class BrandViewHeader : UIView{
    
}
