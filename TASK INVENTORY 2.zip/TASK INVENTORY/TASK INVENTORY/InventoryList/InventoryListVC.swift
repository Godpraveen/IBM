//
//  InventoryListVC.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import UIKit

class InventoryListVC: UIViewController {
    var getInventoryList : [InventoryListElement]?
    var filterData : [InventoryListElement]?
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var  addCategoryButton : UIButton!
    @IBOutlet weak var  oneButton : UIButton!
    @IBOutlet weak var  twoButton : UIButton!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var leftMenuButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "InventoryListTableViewCell", bundle: nil), forCellReuseIdentifier: "InventoryListTableViewCell")
        inventoryApi()
        contentView.layer.cornerRadius = 5
        bottomView.layer.cornerRadius = 5
        tableView.layer.cornerRadius = 5
        tableView.layer.borderWidth = 1
        tableView.layer.borderColor = UIColor.lightGray.cgColor
        addCategoryButton.layer.cornerRadius = 5
        oneButton.layer.cornerRadius = 5
        twoButton.layer.cornerRadius = 5
    }
    @IBAction func addCategory(_ sender : Any){
        
    }
    @IBAction func leftMenuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(identifier: "ViewController")as! ViewController
        controller.modalTransitionStyle = .crossDissolve
        controller.modalPresentationStyle = .overFullScreen
        present(controller, animated: true)
    }
    func inventoryApi(){
        let url = URL(string: "https://apinatco.azurewebsites.net/api/Inventory?customQuery=")
        var request = URLRequest(url: url!)
        request.httpMethod = "GET"
        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { data, response, error in
            let decode =  JSONDecoder()
            do{
                let result =  try decode.decode([InventoryListElement].self, from: data!)
                DispatchQueue.main.async {
                    self.getInventoryList = result
                    self.filterData = result
                    self.tableView.reloadData()
                    print("Response----->\(result)")
                }
            }catch{
                print("Error----->\(error)")
            }
        }.resume()
    }
}

extension InventoryListVC : UITableViewDelegate ,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "InventoryListTableViewCell", for: indexPath)as! InventoryListTableViewCell
        let data = filterData?[indexPath.row]
        cell.createdBy.text = data?.createddate
        cell.productName.text = data?.productname
        cell.productSku.text = data?.productsku
        cell.rowId.text = "\(data?.rowid ?? 0)"
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = Bundle.main.loadNibNamed("InventoryHeader", owner: self, options: nil)?.first as? InventoryHeader
        return header
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
           return 50
       }
}
extension InventoryListVC : UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            filterData = getInventoryList
        }else{
            filterData = getInventoryList?.filter({$0.productname.lowercased().contains(searchText.lowercased())})
        }
        tableView.reloadData()
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        filterData = getInventoryList
        tableView.reloadData()
    }
}
