//
//  AddPriceListVC.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 15/07/24.
//

import UIKit

class AddPriceListVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    

}
