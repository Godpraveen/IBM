//
//  ProductListsTableViewCell.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import UIKit

class ProductListsTableViewCell: UITableViewCell {

    @IBOutlet weak var optionBtn: UIButton!
    @IBOutlet weak var category: UILabel!
    @IBOutlet weak var availabelQty: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var rowId: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
