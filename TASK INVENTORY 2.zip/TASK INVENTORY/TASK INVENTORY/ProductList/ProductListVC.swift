//
//  ProductListVC.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import UIKit

class ProductListVC: UIViewController {
    
    var productListApiFetch : [ProductList]?
    var filterData : [ProductList]?
    @IBOutlet weak var leftMenuButton: UIButton!
    @IBOutlet weak var searchbar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var  addCategoryButton : UIButton!
    @IBOutlet weak var  oneButton : UIButton!
    @IBOutlet weak var  twoButton : UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        filterData = productListApiFetch
        productListApi()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "ProductListsTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductListsTableViewCell")
        searchbar.delegate = self
        contentView.layer.cornerRadius = 5
        bottomView.layer.cornerRadius = 5
        tableView.layer.cornerRadius = 5
        tableView.layer.borderWidth = 1
        tableView.layer.borderColor = UIColor.lightGray.cgColor
        addCategoryButton.layer.cornerRadius = 5
        oneButton.layer.cornerRadius = 5
        twoButton.layer.cornerRadius = 5
    }
    @IBAction func addCategory(_ sender : Any){
        
    }
    @IBAction func leftMenuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(identifier: "ViewController")as! ViewController
        controller.modalPresentationStyle = .overFullScreen
        controller.modalTransitionStyle = .crossDissolve
        present(controller, animated: true)
    }
    
    func productListApi(){
        let url = URL(string: "https://apinatco.azurewebsites.net/api/Products?customQuery=")
        var request = URLRequest(url: url!)
        request.httpMethod = "GET"
        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { data, response, error in
            let decode = JSONDecoder()
            do{
                let result = try decode.decode([ProductList].self, from: data!)
                DispatchQueue.main.async {
                    self.productListApiFetch = result
                    self.filterData = result
                    self.tableView.reloadData()
                    print("Response-----> \(result)")
                }
            }catch{
                print("error-----> \(error)")
            }
        }.resume()
    }

}
extension ProductListVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductListsTableViewCell", for: indexPath)as! ProductListsTableViewCell
        let data = filterData?[indexPath.row]
        cell.availabelQty.text = "\(data?.availableqty ?? 0)"
        cell.category.text = data?.categoryname
        cell.name.text = data?.name
        cell.rowId.text = "\(data?.rowid ?? 0)"
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = Bundle.main.loadNibNamed("ProductListsHeaderView", owner: self, options: nil)?.first as? ProductListsHeaderView
        return header
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
           return 50
       }
}
extension ProductListVC : UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty{
            filterData = productListApiFetch
        }else{
            filterData = productListApiFetch?.filter({$0.name.lowercased().contains(searchText.lowercased() )})
        }
        tableView.reloadData()
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        filterData = productListApiFetch
        tableView.reloadData()
    }
}
