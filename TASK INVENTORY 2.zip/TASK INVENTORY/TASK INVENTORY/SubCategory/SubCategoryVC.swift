//
//  SubCategoryVC.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 09/07/24.
//

import UIKit

class SubCategoryVC: UIViewController, EditSubCategoryDelegate ,DetailsSubCategoryVCDelegate, AddCategoryVCDelegate{
    
    var subCategoryApi : [SubCategoryElement]?
    var filterData : [SubCategoryElement]?
    @IBOutlet weak var tabelView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var addCategoryButton : UIButton!
    @IBOutlet weak var oneButton : UIButton!
    @IBOutlet weak var twoButton : UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        filterData = subCategoryApi
        tabelView.dataSource = self
        tabelView.delegate = self
        tabelView.register(UINib(nibName: "SubCategoryTableViewCell", bundle: nil), forCellReuseIdentifier: "SubCategoryTableViewCell")
        SubCategoryApi()
        searchBar.delegate = self
        contentView.layer.cornerRadius = 5
        bottomView.layer.cornerRadius = 5
        tabelView.layer.cornerRadius = 5
        tabelView.layer.borderWidth = 1
        tabelView.layer.borderColor = UIColor.lightGray.cgColor
        addCategoryButton.layer.cornerRadius = 5
        oneButton.layer.cornerRadius = 5
        twoButton.layer.cornerRadius = 5
    }
    @IBAction func addCategory(_ sender : Any){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "AddSubCategoryVC")as! AddSubCategoryVC
        controller.delegate = self
        present(controller, animated: true)
        
    }

    @IBAction func lrftMenu(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(identifier: "ViewController")as! ViewController

        controller.modalPresentationStyle = .overFullScreen
        controller.modalTransitionStyle = .crossDissolve
        present(controller, animated: true)
        
    }
    func SubCategoryApi(){
        let url = URL(string: "https://apinatco.azurewebsites.net/api/SubCategory")
        var request =  URLRequest(url: url!)
        request.httpMethod = "GET"
        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { data, response, error in
            let decode = JSONDecoder()
            do{
                let result = try decode.decode([SubCategoryElement].self, from: data!)
                DispatchQueue.main.async {
                    self.subCategoryApi = result
                    self.filterData = result
                    self.tabelView.reloadData()
                    print("Response-----> \(result)")
                }
            }catch{
                print("----->Error \(error)")
            }
        }.resume()
    }
}
extension SubCategoryVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SubCategoryTableViewCell", for: indexPath)as! SubCategoryTableViewCell
        let data = filterData?[indexPath.row]
        cell.createdDate.text = data?.createdate
        cell.imageData.text = data?.image
        cell.nameData.text = data?.name
        cell.rowId.text = "\(data?.rowid ?? 0)"
        cell.delegate = self
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = Bundle.main.loadNibNamed("SubCategoryHeader", owner: self, options: nil)?.first as? SubCategoryHeader
        return header
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
           return 50
       }
}
extension SubCategoryVC : UISearchBarDelegate , AddSubCategoryVCDelgate , SubCategoryTableViewCellDelegate{
    func editAction(cell: SubCategoryTableViewCell, action: Action) {
        guard let indexPath =  tabelView.indexPath(for: cell) ,let data = filterData?[indexPath.row]else{
            return
        }
        
        switch action {
        case .editCategory :
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "EditSubCategory") as! EditSubCategory
            controller.rowId = "\(data.rowid )"
            controller.descriptionTextData = data.description
            controller.codeName = data.code
            controller.nameData = data.name
            controller.delegate = self
            present(controller, animated: true)
            
            
            
        case .detailsCategory:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "DetailsSubCategoryVC") as! DetailsSubCategoryVC
            controller.rowIdData = "\(data.rowid)"
            controller.descriptionData = data.description
            controller.codeData = data.code
            controller.disableData = "\(data.disabled)"
            controller.nameData = data.name
            controller.delegate = self
            present(controller, animated: true)
            
        }
    }
    
    func addReq() {
        SubCategoryApi()
        tabelView.reloadData()
    }
    func delete() {
        tabelView.reloadData()
        SubCategoryApi()
    }
    
    func putReq() {
        tabelView.reloadData()
        SubCategoryApi()
    }
    
            func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            if searchText.isEmpty {
                filterData = subCategoryApi
            } else {
                filterData = subCategoryApi?.filter({ $0.name!.lowercased().contains(searchText.lowercased()) })
            }
            
            tabelView.reloadData()
        }
        
        func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
            searchBar.text = ""
            filterData = subCategoryApi
            tabelView.reloadData()
        }
    }
