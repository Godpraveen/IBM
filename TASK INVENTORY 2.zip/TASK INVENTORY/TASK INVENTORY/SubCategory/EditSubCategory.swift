//
//  EditSubCategory.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 15/07/24.
//

import UIKit
protocol EditSubCategoryDelegate : AnyObject{
    func putReq()
}
class EditSubCategory: UIViewController {
    var dataGet : [SubCategoryElement]?
    var filterData : [SubCategoryElement]?
    weak var delegate : EditSubCategoryDelegate?
    @IBOutlet weak var categoryNameTableView: UITableView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var downView: UIView!
    @IBOutlet weak var searchbar: UISearchBar!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var categoryName: UIButton!
    @IBOutlet weak var descriptionText: UITextView!
    @IBOutlet weak var codeText: UITextField!
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var rowidText: UITextField!
    
    var rowId: String?
    var codeName: String?
    var descriptionTextData : String?
    var nameData : String?
   

    override func viewDidLoad() {
        super.viewDidLoad()
        topView.layer.cornerRadius = 10
        downView.layer.cornerRadius = 10
        contentView.layer.cornerRadius = 10
        updateButton.layer.cornerRadius = 5
        closeButton.layer.cornerRadius = 5
       
        descriptionText.layer.borderWidth = 1
        descriptionText.layer.cornerRadius = 1
        descriptionText.layer.borderColor = UIColor.lightGray.cgColor
       
        rowidText.text = rowId
        codeText.text = codeName
        descriptionText.text = descriptionTextData
        nameText.text = nameData
        categoryNameTableView.isHidden = true
        categoryNameTableView.dataSource = self
        categoryNameTableView.delegate = self
        categoryNameTableView.register(UINib(nibName: "CategoryNameTableViewCell", bundle: nil), forCellReuseIdentifier: "CategoryNameTableViewCell")
        SubCategoryApi()
    }
   
    @IBAction func categoryNameButton(_ sender: Any) {
        categoryNameTableView.isHidden = !categoryNameTableView.isHidden
       
    }
    
    @IBAction func updateButton(_ sender: Any) {
        let currentDate = Date()

        // Optionally, you can format the date using a DateFormatter
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // Specify your desired format here
        let formattedDate = dateFormatter.string(from: currentDate)

        print("Current Date: \(formattedDate)")
        guard let rowId = rowidText.text,
                  let name = nameText.text,
                  let description = descriptionText.text,
                  let code = codeText.text,
                  let  categoryNameData = categoryName else {
                return
            }
            
           
            
            // Define the URL
            guard let url = URL(string: "https://apinatco.azurewebsites.net/api/SubCategory?") else {
                print("Invalid URL")
                return
            }
            
            // Create a URLRequest object
            var request = URLRequest(url: url)
            request.httpMethod = "PUT"
            
            // Set headers
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            // request.setValue("Bearer your_access_token", forHTTPHeaderField: "Authorization")
            
            // Create the JSON payload
            let parameters: [String: Any] = [
              
                    "id": rowId,
                    "partitionKey": rowId,
                    "rowid": rowId,
                    "createdate": formattedDate,
                    "createdby": "Admin",
                    "name": name,
                    "code": code,
                    "description": description,
                    "image": "https://",
                    "categoryid": 1,
                    "categoryname": categoryNameData,
                    "disabled": "false"
              
            ]
            
            // Serialize the JSON payload
            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
            } catch {
                print("Error serializing JSON: \(error)")
                return
            }
            
            // Create a URLSession data task
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    print("Error making PUT request: \(error)")
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                    print("Server error")
                    return
                }
                
                if let data = data, let responseBody = String(data: data, encoding: .utf8) {
                    print("Response data: \(responseBody)")
                }
                DispatchQueue.main.async {
                    self.delegate?.putReq()
                    self.showUpdateSuccessAlert()
                }
            }
        task.resume()
       
        }
    func showUpdateSuccessAlert() {
        let alert = UIAlertController(title: "Success", message: "Update Successful", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler:  { _ in
            // Dismiss or navigate away if needed
            self.dismiss(animated: true)
        }))
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func closeButton(_ sender: Any) {
        dismiss(animated: true)
    }
    @IBAction func xCloseButton(_ sender: Any) {
        dismiss(animated: true)
    }
}
extension EditSubCategory : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataGet?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryNameTableViewCell", for: indexPath)as! CategoryNameTableViewCell
        cell.categoryNameTxt.text = dataGet?[indexPath.row].categoryname
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let selectedCategoryName = dataGet?[indexPath.row].categoryname else {
            return
        }
        categoryName.setTitle(selectedCategoryName, for: .normal)
        categoryNameTableView.isHidden = true
    }

    
    func SubCategoryApi(){
        let url = URL(string: "https://apinatco.azurewebsites.net/api/SubCategory")
        var request =  URLRequest(url: url!)
        request.httpMethod = "GET"
        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { data, response, error in
            let decode = JSONDecoder()
            do{
                let result = try decode.decode([SubCategoryElement].self, from: data!)
                DispatchQueue.main.async {
                    self.dataGet = result
                    self.filterData = result
                    self.categoryNameTableView.reloadData()
                    print("Response-----> \(result)")
                }
            }catch{
                print("----->Error \(error)")
            }
        }.resume()
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
    if searchText.isEmpty {
        filterData = dataGet
    } else {
        filterData = dataGet?.filter({ $0.categoryname!.lowercased().contains(searchText.lowercased()) })
    }
    
    categoryNameTableView.reloadData()
}

func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
    searchBar.text = ""
    filterData = dataGet
    categoryNameTableView.reloadData()
 }
}
    

