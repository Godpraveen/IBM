//
//  ViewController.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 08/07/24.
//

import UIKit

class ViewController: UIViewController {
   
    let sections: [menuData] = [
        menuData(headerTitle: "Main", data: ["Dashboard"], image: ["dash"]),menuData(headerTitle: "Product", data: ["Category","Sub Category","Brand","Product","Product Price","Inventory","Unit"], image: ["category","subcat","brand","product","productprice","inventory","unit"]),menuData(headerTitle: "Sales", data: ["Sales","Sales Return","Paid Sales Return","Quotation","Tax Rate"], image: ["String"]),menuData(headerTitle: "Purchases", data: ["Purchase Order","Purchase return","Payment Type","Purchase"], image: ["String"]),menuData(headerTitle: "Peoples" , data: ["Customers","Suppilers","Users","Role","Store"], image: ["String"]),menuData(headerTitle: "Manage Expense", data: ["Expenses","Expenses Category"], image: ["String"]),menuData(headerTitle: "Settings", data: ["Settings","Logout"], image: [""])
    ]
    @IBOutlet weak var tableViewdata: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewdata.dataSource = self
        tableViewdata.delegate = self
        tableViewdata.register(UINib(nibName: "MenuTableViewCell", bundle: nil), forCellReuseIdentifier: "MenuTableViewCell")
        tableViewdata.layer.borderColor = UIColor.lightGray.cgColor
    }

    @IBAction func dismissButton(_ sender: Any) {
       
        self.dismiss(animated: true, completion: nil)
    }
    
}
extension ViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return sections[section].data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuTableViewCell", for: indexPath)as! MenuTableViewCell
        let menuItem = sections[indexPath.section].data[indexPath.row]
        let section = sections[indexPath.section]
           if indexPath.row < section.image.count {
               let menuImage = section.image[indexPath.row]
               cell.mainImage.image = UIImage(named: menuImage)
           }
        cell.mainName.text = menuItem
        
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 40))
        headerView.backgroundColor = UIColor.white
        
        let headerLabel = UILabel(frame: CGRect(x: 10, y: 10, width: tableView.frame.width - 20, height: 20))
        headerLabel.text = sections[section].headerTitle
        headerLabel.font = UIFont.boldSystemFont(ofSize: 16)
        headerLabel.textColor = .darkGray
        
        headerView.addSubview(headerLabel)
        return headerView
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sections[section].headerTitle
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 35
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let loadingImageView = UIImageView(image: UIImage(named: "loading"))
//        let loadingImageView = UIImageView(image: UIImage.gifImageWithName("loading"))
           loadingImageView.center = view.center
           view.addSubview(loadingImageView)
       
       
        if indexPath.section == 1{
            if indexPath.row == 0{
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "ProductCategoryVC") as? ProductCategoryVC
                present(controller!, animated: true)
                
            }
            if indexPath.row == 1{
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "SubCategoryVC") as? SubCategoryVC
                present(controller!, animated: true)
            }
            
            if indexPath.row == 2{
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "BrandListVC") as? BrandListVC
                present(controller!, animated: true)
                
            }
            
            if indexPath.row == 3{
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "ProductListVC") as? ProductListVC
                present(controller!, animated: true)
            }
            if indexPath.row == 4{
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "ProductPriceListVC") as? ProductPriceListVC
                present(controller!, animated: true)
                
            }
            if indexPath.row == 5{
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "InventoryListVC") as? InventoryListVC
                present(controller!, animated: true)
            }
            if indexPath.row == 6{
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "UnitListVC") as? UnitListVC
                present(controller!, animated: true)
            }
        }
    }
    
}
