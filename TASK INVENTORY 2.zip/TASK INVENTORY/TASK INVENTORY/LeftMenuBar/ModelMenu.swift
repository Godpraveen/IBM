//
//  ModelMenu.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 08/07/24.
//

import Foundation
  
struct menuData{
    var headerTitle: String
        var data: [String]
    var image : [String]
    
}


