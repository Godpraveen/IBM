//
//  ProductCategoryTableViewCell.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 08/07/24.
//

import UIKit

protocol ProductCategoryTableViewCellDelegate : AnyObject {
    func editAction(cell : ProductCategoryTableViewCell , action : EditAction)
}
enum EditAction {
    case editCategory
    case detailCategory
}
class ProductCategoryTableViewCell: UITableViewCell {
    weak var delegate : ProductCategoryTableViewCellDelegate?
    @IBOutlet weak var action: UIButton!
    @IBOutlet weak var createdBy: UILabel!
    @IBOutlet weak var code: UILabel!
    @IBOutlet weak var categoryName: UILabel!
    @IBOutlet weak var rowId: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
       setMenu()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    private func setMenu(){
        var menuChildren : [UIMenuElement] = [
        UIAction(title: "Edit", image: UIImage(systemName: "highlighter")) { [weak self] _ in
            self?.editCategory()
        }]
        let edit = UIAction(title: "Details", image: UIImage(systemName: "eye")) { [weak self] _ in
            self?.detailCategory()
        }
        menuChildren.append(edit)
        let menu = UIMenu(title: "" , children: menuChildren)
        action.menu = menu
        action.showsMenuAsPrimaryAction = true
    }
        func editCategory(){
            delegate?.editAction(cell: self, action: .editCategory )
        }
    func detailCategory(){
        delegate?.editAction(cell: self, action: .detailCategory )
    }
    }


