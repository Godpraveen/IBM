//
//  ProductCategoryVC.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 08/07/24.
//

import UIKit

class ProductCategoryVC: UIViewController {
    var getApi : [WelcomeElement]?
    
    var filteredData : [WelcomeElement]?
    @IBOutlet weak var leftMenuButton: UIButton!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var addCategory: UIButton!
    @IBOutlet weak var twoButton: UIButton!
    @IBOutlet weak var oneButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var contentView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        filteredData = getApi
        tableView.dataSource = self
        tableView.delegate = self
        apiCall()
        tableView.reloadData()
        tableView.register(UINib(nibName: "ProductCategoryTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductCategoryTableViewCell")
        contentView.layer.cornerRadius = 5
        bottomView.layer.cornerRadius = 5
        tableView.layer.cornerRadius = 5
        tableView.layer.borderWidth = 1
        tableView.layer.borderColor = UIColor.lightGray.cgColor
        addCategory.layer.cornerRadius = 5
        oneButton.layer.cornerRadius = 5
        twoButton.layer.cornerRadius = 5
        searchBar.placeholder = "Search"
      
       }
   
    func apiCall(){
        let url = URL(string: "https://apinatco.azurewebsites.net/api/Category?customQuery=")
//        print("Error: Invalid URL\(url!)")
        var request = URLRequest(url: url!)
        request.httpMethod = "GET"
        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { data, response, error in
            if let error = error {
                        print("Error: \(error)")
                        return
                    }
                    
                    guard let data = data else {
                        print("Error: No data received")
                        return
                    }
            let decode = JSONDecoder()
            do{
                let result = try decode.decode([WelcomeElement]?.self, from: data)
                
                DispatchQueue.main.async {
                    self.getApi = result
                    self.filteredData = result
                    self.tableView.reloadData()
//                    print("Response-----> \(result!)")
                }
            }catch{
                print("Error ------> \(error)")
            }
        }.resume()
    }
    
    @IBAction func addCategory(_ sender : Any){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "AddCategoryVC")as! AddCategoryVC
        present(controller, animated: true)
        
    }
    @IBAction func leftMenu(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        controller.modalPresentationStyle = .overFullScreen
        controller.view.backgroundColor = UIColor.clear
        present(controller, animated: true)
    }
}
extension ProductCategoryVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCategoryTableViewCell", for: indexPath)as! ProductCategoryTableViewCell
        if let data = filteredData?[indexPath.row] {
            cell.rowId.text = "\(data.rowid)"
            cell.categoryName.text = data.name
            cell.code.text = data.code
            cell.createdBy.text = "\(data.createdby)"
            cell.delegate = self
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        guard let  headerView = Bundle.main.loadNibNamed("HeaderForTableView", owner: self, options: nil)?.first as? HeaderForTableView else {
            return nil
        }
        return headerView
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    func putReq() {
        apiCall()
        tableView.reloadData()
    }
    func addReq() {
        apiCall()
        tableView.reloadData()
    }
    func delete() {
        apiCall()
        tableView.reloadData()
       }
}
extension ProductCategoryVC : UISearchBarDelegate{
        func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            if searchText.isEmpty {
                filteredData = getApi
            } else {
                filteredData = getApi?.filter({ $0.name.lowercased().contains(searchText.lowercased()) })
            }
            
            tableView.reloadData()
        }
        
        func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
            searchBar.text = ""
            filteredData = getApi
            tableView.reloadData()
        }
    }
    

extension ProductCategoryVC : ProductCategoryTableViewCellDelegate , PCategoryVCDelegate, DeatilsProductCVCDelegate  , AddCategoryVCDelegate{
   
   
    
   
    
    func editAction(cell: ProductCategoryTableViewCell, action: EditAction) {
        guard let indexPath =  tableView.indexPath(for: cell) ,let data = filteredData?[indexPath.row]else{
            return
        }
        
        switch action {
        case .editCategory :
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "PCategoryVC") as! PCategoryVC
            controller.rowId = "\(data.rowid )"
            controller.descriptionTextData = data.description
            controller.codeName = data.code
            controller.nameData = data.name
            controller.delegate = self
            present(controller, animated: true)
            
            
            
        case .detailCategory:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "DeatilsProductCVC") as! DeatilsProductCVC
            controller.rowIdData = "\(data.rowid)"
            controller.descriptionData = data.description
            controller.codeData = data.code
            controller.disableData = "\(data.disabled)"
            controller.nameData = data.name
            controller.delegate = self
            present(controller, animated: true)
            
        }
        
    }
}

