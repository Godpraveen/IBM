import UIKit
import GoogleMaps

class ViewController: UIViewController {
    private var mapView: GMSMapView?

    override func viewDidLoad() {
        super.viewDidLoad()

        GMSServices.provideAPIKey("AIzaSyBOcM01Em7oQbrbojC4BWRkJ_pG7-Vvp3o") // Make sure to replace YOUR_API_KEY with your actual API key
        setupMapView()
        showLocation(latitude: 12.9473, longitude: 77.5967)
    }

    private func setupMapView() {
        let camera = GMSCameraPosition.camera(withLatitude: 12.9473, longitude: 77.5967, zoom: 20.0)
        mapView = GMSMapView.map(withFrame: view.bounds, camera: camera)
        view.addSubview(mapView!)
    }

    private func showLocation(latitude: CLLocationDegrees, longitude: CLLocationDegrees) {
        guard let mapView = mapView else { return }

        // Update the camera position
        let camera = GMSCameraPosition.camera(withLatitude: latitude, longitude: longitude, zoom: 20.0)
        mapView.animate(to: camera)

        // Add a marker
        let marker = GMSMarker()
        marker.position = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        marker.title = "Location"
        marker.snippet = "12.9473° N, 77.5967° E"
        marker.map = mapView
    }
}
