//
//  Constans.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 12/07/24.
//

import Foundation


import Foundation


//MARK: - Base URL
let BaseURL = "https://apinatco.azurewebsites.net/api/"


// MARK: - Product URL
let CategoryURL = BaseURL +  "Category?"
let SubCateogryURL =   BaseURL + "SubCategory?customQuery="
let ProductBrandURL = BaseURL + "Brand?customQuery="
let ProductURL = BaseURL + "Products?customQuery="
let PriceURL = BaseURL + "Productprice?customQuery="
let ProductInventoryURL = BaseURL + "Inventory?customQuery="
let ProductUnitURL = BaseURL + "Unit?customQuery="


// MARK: - Sales URL
let POSURL = BaseURL + "Pos?"
let SalesURL = BaseURL + "Sales?customQuery="
let SaleDetailsURL = BaseURL + "SaleDetails?customQuery="
let SalesPaymentURL = BaseURL + "SalesPayment?customQuery="
let SalesReturnURL = BaseURL + "SalesReturn?"
let SalesReturnPaymentURL = BaseURL + "SalesReturnPayment?"
let QuotationURL = BaseURL + "Quotation?customQuery="
let QuotationdetailsURL = BaseURL + "Quotationdetails?customQuery="
let DiscounttypeURL = BaseURL + "Discounttype?customQuery="
let AddTransferURL = BaseURL + "AddTransfer?"
let TaxrateURL = BaseURL + "Taxrate?customQuery="

//MARK: - Purchases URL

let PurchaseorderURL = BaseURL + "Purchase?"
let PurchaseReturnURL = BaseURL + "PurchaseReturn?"
let PaymentTypeURL = BaseURL + "PaymentType?"
let purchaseDetailsURL = BaseURL + "PurchaseDetails?"
let purchasePaymentURL = BaseURL + "purchasePayment"
//MARK: - Peoples URL

let CustomerURL = BaseURL + "Customer?"
let SupplierURL = BaseURL + "Supplier?"
let UserURL = BaseURL + "User?"
let RoleURL = BaseURL + "Role?"
let StoresURL = BaseURL + "Stores?"


//MARK: - Manage Expense URL
let ExpenseURL = BaseURL + "Expense?"
let ExpenseCategoryURL = BaseURL + "ExpenseCategory?"

var LoginUser = "Admin"

/*
    // MARK: - Product URL
    let CategoryURL = "Cat"
    let SubCateogryURL = "SubCat"
    let ProductBrandURL = "Brand"
    let ProductURL = "Product.json"
    let ProductpriceURL = "ProductPrice"
    let InventoryURL = "Inventory"
    let ProductUnitURL = "Unit"


    // MARK: - Sales URL
    let POSURL = "Pos"
    let SalesURL = "Sales"
    let SaleDetailsURL = "SaleDetails"
    let SalesPaymentURL = "SalesPayment"
    let SalesReturnURL = "SalesReturn"
    let SalesReturnPaymentURL = "SalesReturnPayment"
    let QuotationURL = "Quotation"
    let QuotationdetailsURL = "Quotationdetails"
    let DiscounttypeURL = "DiscountType"
    let AddTransferURL = "AddTransfer"
    let TaxrateURL = "TaxRate"

    //MARK: - Purchases URL

    let PurchaseorderURL = "Purchaseorder"
    let PurchaseReturnURL = "PurchaseReturn"
    let PaymentTypeURL = "PaymentType"

    //MARK: - Peoples URL

    let CustomerURL = "Customer"
    let SupplierURL = "Supplier"
    let UserURL = "User"
    let RoleURL = "Role"
    let StoresURL = "Stores"


    //MARK: - Manage Expense URL
    let ExpenseURL = "Expense"
    let ExpenseCategoryURL = "ExpenseCategory"

https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/?
https://apinatco.azurewebsites.net/api/?
https://apinatco.azurewebsites.net/api/CompanyDetails?
https://apinatco.azurewebsites.net/api/?
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/?
https://apinatco.azurewebsites.net/api/PaymentGeneral?
https://apinatco.azurewebsites.net/api/PaymentTerm?
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/?
https://apinatco.azurewebsites.net/api/?
https://apinatco.azurewebsites.net/api/Purchase?
https://apinatco.azurewebsites.net/api/PurchaseDetails?
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/Purchaseorderdetails?
https://apinatco.azurewebsites.net/api/PurchasePayment?
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/SaleDetails?
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/StockDetails?
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/?
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/
https://apinatco.azurewebsites.net/api/?
https://apinatco.azurewebsites.net/api/
*/
