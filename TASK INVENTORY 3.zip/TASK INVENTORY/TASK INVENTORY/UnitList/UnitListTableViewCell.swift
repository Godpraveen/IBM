//
//  UnitListTableViewCell.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import UIKit

class UnitListTableViewCell: UITableViewCell {

    @IBOutlet weak var optionButton: UIButton!
    @IBOutlet weak var createdBy: UILabel!
    @IBOutlet weak var craetedDate: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var rowId: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
