//
//  BrandListTableViewCell.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 09/07/24.
//

import UIKit
protocol BrandListTableViewCellDelegate : AnyObject {
    func editAction(cell : BrandListTableViewCell , action : editAction)
}
enum editAction {
    case editCategory
    case detailCategory
}
class BrandListTableViewCell: UITableViewCell {
    weak var delegate : BrandListTableViewCellDelegate?
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var crearedBy: UILabel!
    @IBOutlet weak var imageLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var rowIdLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
       setMenu()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    private func setMenu(){
        var menuChildren : [UIMenuElement] = [
        UIAction(title: "Edit", image: UIImage(systemName: "highlighter")) { [weak self] _ in
            self?.editCategory()
        }]
        let edit = UIAction(title: "Details", image: UIImage(systemName: "eye")) { [weak self] _ in
            self?.detailCategory()
        }
        menuChildren.append(edit)
        let menu = UIMenu(title: "" , children: menuChildren)
        menuButton.menu = menu
        menuButton.showsMenuAsPrimaryAction = true
    }
        func editCategory(){
            delegate?.editAction(cell: self, action: .editCategory )
        }
    func detailCategory(){
        delegate?.editAction(cell: self, action: .detailCategory )
    }
    }


