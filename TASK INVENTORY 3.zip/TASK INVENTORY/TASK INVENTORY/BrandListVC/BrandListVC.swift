//
//  BrandListVC.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 09/07/24.
//

import UIKit

class BrandListVC: UIViewController, EditBrandVcDelegate, DetailsBrandVCDelegate, AddBrandListVCDelegate {
    func addReq() {
        brandListApi()
         tableViewBrandList.reloadData()
    }
    
    func delete() {
       brandListApi()
        tableViewBrandList.reloadData()
        
    }
    
    func putReq() {
        brandListApi()
         tableViewBrandList.reloadData()
    }
    
   
    
  
    
    
    var productList : [ProductListElement]?
    var filterData : [ProductListElement]?

    @IBOutlet weak var lefftMenuButton: UIButton!
  
    var isMenuButtonRotated = false
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableViewBrandList: UITableView!
    @IBOutlet weak var contemntView: UIView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var  addCategoryButton : UIButton!
    @IBOutlet weak var  oneButton : UIButton!
    @IBOutlet weak var  twoButton : UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        filterData = productList
        brandListApi()
        tableViewBrandList.dataSource = self
        tableViewBrandList.delegate = self
        tableViewBrandList.register(UINib(nibName: "BrandListTableViewCell", bundle: nil), forCellReuseIdentifier: "BrandListTableViewCell")
        searchBar.delegate = self
        contemntView.layer.cornerRadius = 5
        bottomView.layer.cornerRadius = 5
        tableViewBrandList.layer.cornerRadius = 5
        tableViewBrandList.layer.borderWidth = 1
        tableViewBrandList.layer.borderColor = UIColor.lightGray.cgColor
        addCategoryButton.layer.cornerRadius = 5
        oneButton.layer.cornerRadius = 5
        twoButton.layer.cornerRadius = 5
       
    }
    
    @IBAction func addCategory(_ sender : Any){
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(identifier: "AddBrandListVC")as! AddBrandListVC
        controller.delegate = self
        present(controller, animated: true)
        
    }
    @IBAction func leftMenuButton(_ sender: Any) {
       
    
//        UIView.animate(withDuration: 0.5, animations: {
//                   if self.isMenuButtonRotated {
//                       self.lefftMenuButton.transform = .identity // Rotate back to original
//                   } else {
//                       self.lefftMenuButton.transform = CGAffineTransform(rotationAngle: .pi) // Rotate 180 degrees
//                   }
//               }) { _ in
//                   self.isMenuButtonRotated.toggle() // Toggle rotation state
//                   
//                   // Toggle button image based on rotation state
//                   if self.isMenuButtonRotated {
//                       self.lefftMenuButton.setImage(UIImage(systemName: "xmark"), for: .normal)
//                   } else {
//                       self.lefftMenuButton.setImage(UIImage(systemName: "menu-list"), for: .normal)
//                   }
//               }
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(identifier: "ViewController")as! ViewController
        controller.modalTransitionStyle = .crossDissolve
        controller.modalPresentationStyle = .overFullScreen
        present(controller, animated: true)
    }
    
    func brandListApi (){
        let url = URL(string: "https://apinatco.azurewebsites.net/api/Brand?customQuery=")
        var request = URLRequest(url: url!)
        request.httpMethod = "GET"
        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { data, response, error in
            let decode = JSONDecoder()
            do{
                let result = try decode.decode([ProductListElement].self, from: data!)
                DispatchQueue.main.async {
                    self.productList = result
                    self.filterData = result
                    self.tableViewBrandList.reloadData()
                    print("Response-----> \(result)")
                }
            }catch{
                print("Error -----> \(error)")
            }
        }.resume()
    }

}

extension BrandListVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BrandListTableViewCell", for: indexPath)as! BrandListTableViewCell
        let data = filterData?[indexPath.row]
        cell.crearedBy.text = data?.createddate
        cell.imageLabel.text = data?.image
        cell.nameLabel.text = data?.name
        cell.rowIdLabel.text = "\(data?.rowid ?? 0)"
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = Bundle.main.loadNibNamed("BrandViewHeader", owner: self, options:  nil)?.first as? BrandViewHeader
        return header
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
           return 50
       }
}
extension BrandListVC : UISearchBarDelegate{
        func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            if searchText.isEmpty {
                filterData = productList
            } else {
                filterData = productList?.filter({ $0.name.lowercased().contains(searchText.lowercased()) })
            }
            
            tableViewBrandList.reloadData()
        }
        
        func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
            searchBar.text = ""
            filterData = productList
            tableViewBrandList.reloadData()
        }
    }
extension BrandListVC : BrandListTableViewCellDelegate {
    func editAction(cell: BrandListTableViewCell, action: editAction) {
        guard let indexPath =  tableViewBrandList.indexPath(for: cell) ,let data = filterData?[indexPath.row]else{
            return
        }
        
        switch action {
        case .editCategory :
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "EditBrandVc") as! EditBrandVc
            controller.rowId = "\(data.rowid )"
            controller.descriptionTextData = data.description
            controller.codeName = data.image
            controller.nameData = data.name
            controller.delegate = self
            present(controller, animated: true)
            
            
            
        case .detailCategory:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "DetailsBrandVC") as! DetailsBrandVC
            controller.rowIdData = "\(data.rowid)"
            controller.descriptionData = data.description
            controller.codeData = data.image
            controller.disableData = "\(data.disabled)"
            controller.nameData = data.name
            controller.delegate = self
            present(controller, animated: true)
            
        }
    }
    
    
}
    
   
   

