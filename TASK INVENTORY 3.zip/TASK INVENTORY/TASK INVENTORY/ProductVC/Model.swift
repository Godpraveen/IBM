//
//  Model.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 08/07/24.
//

import Foundation
// MARK: - WelcomeElement
struct WelcomeElement: Codable {
    let id: String
    let partitionKey: String
    let rowid: Int
    let name: String
    let code: String
    let description: String
    let createdby: String
    let createddate: String
    let image: String?
    let disabled: Bool
}
