//
//  DeatilsProductCVC.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 11/07/24.
//

import UIKit
protocol DeatilsProductCVCDelegate : AnyObject{
    func delete()
}
class DeatilsProductCVC: UIViewController {
    weak var delegate : DeatilsProductCVCDelegate?
    var rowIdGet : Int?
    @IBOutlet weak var rowIdText: UITextField!
    @IBOutlet weak var descriptionText: UITextView!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var downView: UIView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var disabledText: UITextField!
    @IBOutlet weak var codeText: UITextField!
    @IBOutlet weak var nameText: UITextField!
    var nameData : String?
    var codeData : String?
    var disableData : String?
    var rowIdData : String?
    var descriptionData : String?
    var apiData : WelcomeElement?
    override func viewDidLoad() {
        super.viewDidLoad()
        topView.layer.cornerRadius = 10
        downView.layer.cornerRadius = 10
        contentView.layer.cornerRadius = 10
        deleteButton.layer.cornerRadius = 5
        closeButton.layer.cornerRadius = 5
        descriptionText.layer.borderWidth = 1
        descriptionText.layer.cornerRadius = 1
        descriptionText.layer.borderColor = UIColor.lightGray.cgColor
        nameText.text = nameData
        descriptionText.text = descriptionData
        rowIdText.text = rowIdData
        disabledText.text = disableData
        codeText.text = codeData
        if let category = apiData {
            nameData = category.name
            descriptionData = category.description
            rowIdData = "\(category.rowid )"
            disableData = "\(category.disabled)"
            codeData = category.code
        }
        
    }
    
    
    
    @IBAction func xClose(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func deleteButton(_ sender: Any) {
        guard let rowIdString = rowIdData, let rowId = Int(rowIdString) else {
                    print("Row ID is nil or not valid")
                    return
                }
                
                // Construct the URL with query parameters
                var urlComponents = URLComponents(string: "https://apinatco.azurewebsites.net/api/Category")!
                urlComponents.queryItems = [URLQueryItem(name: "customQuery", value: "\(rowId)")]
                
                guard let url = urlComponents.url else {
                    print("Invalid URL")
                    return
                }
                
                var request = URLRequest(url: url)
                request.httpMethod = "DELETE"
                
                // Example body data (if required by the API)
                let bodyData: [String: Any] = [
                    "id": rowId,
                    "partitionKey": rowId
                ]
                
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: bodyData, options: [])
                    request.httpBody = jsonData
                } catch {
                    print("Error encoding body data: \(error)")
                    return
                }
                
                let task = URLSession.shared.dataTask(with: request) { [weak self] (data, response, error) in
                    if let error = error {
                        print("Error deleting data: \(error)")
                        return
                    }
                    
                    if let httpResponse = response as? HTTPURLResponse {
                        print("HTTP Status Code: \(httpResponse.statusCode)")
                        
                        if httpResponse.statusCode == 200 {
                            DispatchQueue.main.async {
                                self?.showDeleteSuccessAlert()
                                self?.delegate?.delete()
                            }
                        } else {
                            print("Unexpected HTTP status code: \(httpResponse.statusCode)")
                        }
                    }
                }
                
                task.resume()
            }
            
            func showDeleteSuccessAlert() {
                let alert = UIAlertController(title: "Success", message: "Delete Successful", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                    // Dismiss or navigate away if needed
                    self.dismiss(animated: true)
                }))
                self.present(alert, animated: true, completion: nil)
            }

      
      
    @IBAction func closeButton(_ sender: Any) {
        dismiss(animated: true)
    }
}

