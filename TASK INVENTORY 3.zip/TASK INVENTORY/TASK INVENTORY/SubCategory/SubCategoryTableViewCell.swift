//
//  SubCategoryTableViewCell.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 09/07/24.
//

import UIKit
protocol SubCategoryTableViewCellDelegate : AnyObject{
    func editAction(cell : SubCategoryTableViewCell , action : Action)
}
enum Action {
    case editCategory
    case detailsCategory
}
class SubCategoryTableViewCell: UITableViewCell {
    weak var delegate : SubCategoryTableViewCellDelegate?
    @IBOutlet weak var rowId: UILabel!
    @IBOutlet weak var nameData: UILabel!
    @IBOutlet weak var imageData: UILabel!
    @IBOutlet weak var createdDate: UILabel!
    @IBOutlet weak var threeDotMenu: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
       setupMenu()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setupMenu(){
        var menuChildren : [UIMenuElement] = [
            UIAction(title: "Edit", image:  UIImage(systemName: "highlighter")) { [weak self] _ in
                self?.editCategory()
            }]
            let details = UIAction(title: "Details",image: UIImage(systemName: "eye")) { [weak self ] _ in
                self?.detailsCategory()
            }
        menuChildren.append(details)
        let menu = UIMenu(title: "",children: menuChildren)
        threeDotMenu.menu = menu
        threeDotMenu.showsMenuAsPrimaryAction = true
    }
    func editCategory() {
        self.delegate?.editAction(cell: self, action: .editCategory)
    }
    func detailsCategory(){
        self.delegate?.editAction(cell: self, action: .detailsCategory)
    }
  
}
