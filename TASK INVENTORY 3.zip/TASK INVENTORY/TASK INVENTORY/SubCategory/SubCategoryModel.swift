//
//  SubCategoryModel.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 09/07/24.
//

import Foundation
struct SubCategoryElement: Codable {
    let id, partitionKey: String?
    let rowid: Int
    let createdate: String?
    let createdby: String?
    let name, code, description: String?
    let image: String?
    let categoryid: Int?
    let categoryname: String?
    let disabled: Bool
}
