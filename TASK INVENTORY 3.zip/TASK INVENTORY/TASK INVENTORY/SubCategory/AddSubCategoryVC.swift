//
//  AddCategoryVC.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 12/07/24.
//

import UIKit
protocol AddSubCategoryVCDelgate : AnyObject {
    func addReq()
}
class AddSubCategoryVC: UIViewController {
    weak var delegate : AddCategoryVCDelegate?
    @IBOutlet weak var rowIdText: UITextField!
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var codeText: UITextField!
    @IBOutlet weak var xcloseButton: UIButton!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var downView: UIView!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var createdByText: UITextField!
    @IBOutlet weak var descriptionText: UITextView!
    var nameData : String?
    var codeData : String?
    var rowIdData : String?
    var createdByData : String?
    var descriptionData : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        createdByText.text = createdByData
        rowIdText.text = rowIdData
        codeText.text = codeData
        descriptionText.text = descriptionData
        nameText.text = nameData
        
        topView.layer.cornerRadius = 10
        downView.layer.cornerRadius = 10
        contentView.layer.cornerRadius = 10
        addButton.layer.cornerRadius = 5
        closeButton.layer.cornerRadius = 5
        descriptionText.layer.borderWidth = 1
        descriptionText.layer.cornerRadius = 1
        descriptionText.layer.borderColor = UIColor.lightGray.cgColor
    }
    
    @IBAction func xButton(_ sender: Any) {
        dismiss(animated: true)
    }
    
   
    @IBAction func addButton(_ sender: Any) {
        let currentDate = Date()

        // Optionally, you can format the date using a DateFormatter
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // Specify your desired format here
        let formattedDate = dateFormatter.string(from: currentDate)

        print("Current Date: \(formattedDate)")

     guard let rowId = rowIdText.text,
        let name = nameText.text,
        let description = descriptionText.text,
        let code = codeText.text,
        let createdBy = createdByText.text else {
      return
  }
  
  
  // Define the URL
  guard let url = URL(string: "https://apinatco.azurewebsites.net/api/SubCategory?") else {
      print("Invalid URL")
      return
  }
  
  // Create a URLRequest object
  var request = URLRequest(url: url)
  request.httpMethod = "POST"
  
  // Set headers
  request.setValue("application/json", forHTTPHeaderField: "Content-Type")
  
  // Create the JSON payload
  let parameters: [String: Any] = [
      "id": rowId,
      "partitionKey": rowId,
      "rowid": rowId,
      "createdate": formattedDate,
      "createdby": createdBy,
      "name": name,
      "code": code,
      "description": description,
      "image": "https://",
      "categoryid": 1,
      "categoryname": "Lugs & Connectors",
      "disabled": true
  ]
  
  // Serialize the JSON payload
  do {
      request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
  } catch {
      print("Error serializing JSON: \(error)")
      return
  }
  
  // Create a URLSession data task
  let task = URLSession.shared.dataTask(with: request) { data, response, error in
      if let error = error {
          print("Error making POST request: \(error)")
          return
      }
      
      guard let httpResponse = response as? HTTPURLResponse else {
          print("No HTTP response")
          return
      }
      
      // Check HTTP status code
      if !(200...299).contains(httpResponse.statusCode) {
          print("HTTP status code: \(httpResponse.statusCode)")
          return
      }
      
      // Check if data was received
      guard let data = data else {
          print("No data received")
          return
      }
      
      // Optionally, print response data
      if let responseBody = String(data: data, encoding: .utf8) {
          print("Response data: \(responseBody)")
      }
      
      // Update UI on the main thread
      DispatchQueue.main.async {
          self.delegate?.addReq()
          self.showUpdateSuccessAlert()
      }
  }
  task.resume()
}

    func showUpdateSuccessAlert() {
        let alert = UIAlertController(title: "Success", message: "Category Added Successful", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            // Dismiss or navigate away if needed
            self.dismiss(animated: true)
        }))
       
        self.present(alert, animated: true, completion: nil)
       
    }
    
    @IBAction func closeButton(_ sender: Any) {
        dismiss(animated: true)
    }
}
