//
//  InventoryModel.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import Foundation

// MARK: - InventoryListElement
struct InventoryListElement: Codable {
    let id, partitionKey: String
    let rowid: Int
    let createddate: String
    let createdby: String
    let productid: Int
    let productname: String
    let productsku: String
    let categoryid: Int
    let categoryname: String
    let subcategoryid: Int
    let subcategoryname: String
    let brandid: Int
    let brandname: String
    let unitid: Int
    let unitname: String
    let transactiontype: String
    let transactionid, quantity: Int
    let transcationdate: String
    let expirydate: String
}
