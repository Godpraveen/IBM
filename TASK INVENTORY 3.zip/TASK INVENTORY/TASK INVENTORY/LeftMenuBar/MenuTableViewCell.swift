//
//  MenuTableViewCell.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 08/07/24.
//

import UIKit

class MenuTableViewCell: UITableViewCell {
    @IBOutlet weak var mainImage: UIImageView!
    @IBOutlet weak var arrowImage: UIImageView!
    @IBOutlet weak var mainName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        arrowImage.image = UIImage(named: "next-2")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
}
