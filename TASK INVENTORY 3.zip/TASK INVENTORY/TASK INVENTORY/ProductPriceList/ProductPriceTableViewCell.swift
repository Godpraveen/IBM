//
//  ProductPriceTableViewCell.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import UIKit

class ProductPriceTableViewCell: UITableViewCell {

    @IBOutlet weak var optionButton: UIButton!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var discount: UILabel!
    @IBOutlet weak var productName: UILabel!
    @IBOutlet weak var rowId: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
