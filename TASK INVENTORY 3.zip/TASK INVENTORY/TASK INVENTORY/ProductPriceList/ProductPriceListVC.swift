//
//  ProductPriceListVC.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import UIKit

class ProductPriceListVC: UIViewController {
    var productPriceGet : [ProductPriceElement]?
    var filterData : [ProductPriceElement]?
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var leftMenuButton: UIButton!
    @IBOutlet weak var  addCategoryButton : UIButton!
    @IBOutlet weak var  oneButton : UIButton!
    @IBOutlet weak var  twoButton : UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        productPriceApi()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "ProductPriceTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductPriceTableViewCell")
        searchBar.delegate = self
        contentView.layer.cornerRadius = 5
        bottomView.layer.cornerRadius = 5
        tableView.layer.cornerRadius = 5
        tableView.layer.borderWidth = 1
        tableView.layer.borderColor = UIColor.lightGray.cgColor
        addCategoryButton.layer.cornerRadius = 5
        oneButton.layer.cornerRadius = 5
        twoButton.layer.cornerRadius = 5
        
    }
    

    func productPriceApi(){
        let url = URL(string: "https://apinatco.azurewebsites.net/api/ProductPrice?customQuery=")
        var request = URLRequest(url: url!)
        request.httpMethod = "GET"
        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { data, response, error in
            let decode = JSONDecoder()
            do{
                let result = try decode.decode([ProductPriceElement].self, from: data!)
                DispatchQueue.main.async {
                    self.productPriceGet = result
                    self.filterData = result
                    self.tableView.reloadData()
                    print("Response----->\(result)")
                }
            }catch{
                print("Error----->\(error)")
            }
        }.resume()
        
    }
    @IBAction func addCategory(_ sender : Any){
        
    }
    @IBAction func leftMenuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(identifier: "ViewController")as! ViewController
        controller.modalTransitionStyle = .crossDissolve
        controller.modalPresentationStyle = .overFullScreen
        present(controller, animated: true)
    }
}
extension ProductPriceListVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductPriceTableViewCell", for: indexPath)as! ProductPriceTableViewCell
        let data = filterData?[indexPath.row]
        cell.discount.text = "nil"
        cell.price.text = data?.price
        cell.productName.text = data?.productname
        cell.rowId.text = "\(data?.rowid ?? 0)"
        
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = Bundle.main.loadNibNamed("ProductPriceHeader", owner: self, options: nil)?.first as? ProductPriceHeader
        return header
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
           return 50
       }
}
extension ProductPriceListVC : UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty{
            filterData = productPriceGet
        }else{
            filterData = productPriceGet?.filter({$0.productname.lowercased().contains(searchText.lowercased())})
        }
        tableView.reloadData()
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        filterData = productPriceGet
        tableView.reloadData()
    }
}
