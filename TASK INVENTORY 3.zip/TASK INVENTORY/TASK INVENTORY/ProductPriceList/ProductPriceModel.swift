//
//  ProductPriceModel.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import Foundation
// MARK: - ProductPriceElement
struct ProductPriceElement: Codable {
    let id, partitionKey: String
    let rowid: Int
    let createddate: String
    let createdby: String
    let price, taxid: String
    let taxname: String
    let productid: Int
    let productname: String
    let disabled: Bool
}
