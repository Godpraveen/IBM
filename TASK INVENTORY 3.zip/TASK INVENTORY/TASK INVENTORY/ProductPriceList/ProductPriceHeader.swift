//
//  ProductPriceHeader.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import Foundation
import UIKit
class ProductPriceHeader : UIView {
    
}
