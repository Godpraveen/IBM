//
//  EditProductListVC.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 15/07/24.
//

import UIKit
protocol EditProductListVCDelegate : AnyObject{
    func putReq()
}
class EditProductListVC: UIViewController {

    weak var delegate : EditProductListVCDelegate?
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var downView: UIView!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var checkBox: UIButton!
    @IBOutlet weak var descriptionText: UITextView!
    @IBOutlet weak var codeText: UITextField!
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var rowidText: UITextField!
    var isChecked = false
    var rowId: String?
    var codeName: String?
    var descriptionTextData : String?
    var nameData : String?
   

    override func viewDidLoad() {
        super.viewDidLoad()
        topView.layer.cornerRadius = 10
        downView.layer.cornerRadius = 10
        contentView.layer.cornerRadius = 10
        updateButton.layer.cornerRadius = 5
        closeButton.layer.cornerRadius = 5
        checkBox.setImage(UIImage(named: "notick"), for: .normal)
        descriptionText.layer.borderWidth = 1
        descriptionText.layer.cornerRadius = 1
        descriptionText.layer.borderColor = UIColor.lightGray.cgColor
       
        rowidText.text = rowId
        codeText.text = codeName
        descriptionText.text = descriptionTextData
        nameText.text = nameData
    }
    func updateCheckBoxImage() {
            let imageName = isChecked ? "tick" : "notick"
            checkBox.setImage(UIImage(named: imageName), for: .normal)
        }
    @IBAction func checkBoxButton(_ sender: Any) {
       
        isChecked = !isChecked
        updateCheckBoxImage()
    }
    
    @IBAction func updateButton(_ sender: Any) {
        let currentDate = Date()

        // Optionally, you can format the date using a DateFormatter
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // Specify your desired format here
        let formattedDate = dateFormatter.string(from: currentDate)

        print("Current Date: \(formattedDate)")
        guard let rowId = rowidText.text,
                  let name = nameText.text,
                  let description = descriptionText.text,
                  let code = codeText.text else {
                return
            }
            
            let isCheckedValue = isChecked ? 1 : 0
            
            // Define the URL
            guard let url = URL(string: "https://apinatco.azurewebsites.net/api/Products?customQuery=") else {
                print("Invalid URL")
                return
            }
            
            // Create a URLRequest object
            var request = URLRequest(url: url)
            request.httpMethod = "PUT"
            
            // Set headers
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            // request.setValue("Bearer your_access_token", forHTTPHeaderField: "Authorization")
            
            // Create the JSON payload
            let parameters: [String: Any] = [
                "id": rowId,
                        "partitionKey": rowId,
                        "rowid": rowId,
                        "createddate": formattedDate,
                        "createdby": "Admin",
                        "name": name,
                        "code": code,
                        "sku": "BRT001",
                        "description": description,
                        "image": "https:",
                        "categoryid": 1,
                        "categoryname": "LUGS & CONNECTORS",
                        "subcategoryid": 1,
                        "subcategoryname": "Cooper Cable Lugs",
                        "brandid": 4,
                        "brandname": "BRILLIANT",
                        "unitid": 1,
                        "unitname": "PIECE",
                        "reorderlevel": 50,
                        "availableqty": 250,
                        "status": isCheckedValue
                
            ]
            
            // Serialize the JSON payload
            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
            } catch {
                print("Error serializing JSON: \(error)")
                return
            }
            
            // Create a URLSession data task
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    print("Error making PUT request: \(error)")
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                    print("Server error")
                    return
                }
                
                if let data = data, let responseBody = String(data: data, encoding: .utf8) {
                    print("Response data: \(responseBody)")
                }
                DispatchQueue.main.async {
                    self.delegate?.putReq()
                    self.showUpdateSuccessAlert()
                }
            }
        task.resume()
       
        }
    func showUpdateSuccessAlert() {
        let alert = UIAlertController(title: "Success", message: "Update Successful", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler:  { _ in
            // Dismiss or navigate away if needed
            self.dismiss(animated: true)
        }))
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func closeButton(_ sender: Any) {
        dismiss(animated: true)
    }
    @IBAction func xCloseButton(_ sender: Any) {
        dismiss(animated: true)
    }
}
