//
//  ProductListModel.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import Foundation
// MARK: - ProductListElement
struct ProductList: Codable {
    let id, partitionKey: String
    let rowid: Int
    let createddate: String
    let createdby: String
    let name, code, sku, description: String
    let image: String
    let categoryid: Int
    let categoryname: String
    let subcategoryid: Int
    let subcategoryname: String
    let brandid: Int
    let brandname: String
    let unitid: Int
    let unitname: String
    let reorderlevel, availableqty: Int
    let status: Bool
}
