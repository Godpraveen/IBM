//
//  ProductListsTableViewCell.swift
//  TASK INVENTORY
//
//  Created by Toqsoft on 10/07/24.
//

import UIKit
protocol ProductListsTableViewCellDelegate : AnyObject {
    func editAction(cell : ProductListsTableViewCell , action : fditAction)
}
enum fditAction {
    case editCategory
    case detailCategory
}
class ProductListsTableViewCell: UITableViewCell {
    weak var delegate : ProductListsTableViewCellDelegate?
    @IBOutlet weak var optionBtn: UIButton!
    @IBOutlet weak var category: UILabel!
    @IBOutlet weak var availabelQty: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var rowId: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        setMenu()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    private func setMenu(){
        var menuChildren : [UIMenuElement] = [
        UIAction(title: "Edit", image: UIImage(systemName: "highlighter")) { [weak self] _ in
            self?.editCategory()
        }]
        let edit = UIAction(title: "Details", image: UIImage(systemName: "eye")) { [weak self] _ in
            self?.detailCategory()
        }
        menuChildren.append(edit)
        let menu = UIMenu(title: "" , children: menuChildren)
        optionBtn.menu = menu
        optionBtn.showsMenuAsPrimaryAction = true
    }
        func editCategory(){
            delegate?.editAction(cell: self, action: .editCategory )
        }
    func detailCategory(){
        delegate?.editAction(cell: self, action: .detailCategory )
    }
    }
